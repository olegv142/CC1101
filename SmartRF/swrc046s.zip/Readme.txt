
Texas Instruments, Inc.

SmartRF Studio  Release Notes

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
N O T E!
To ensure that everything is cleaned up from the startup menu, it is 
recommended to uninstall the old version before installing the new version.
-------------------------------------------------------------------------------
Version 6.13.1.0 January 25. 2010
-------------------------------------------------------------------------------
- CC430 : - Fixed problem to start session for CC430.
          - Updated SW to access CC430EM: msp430.dll version 2.4.2.0 
-------------------------------------------------------------------------------
Version 6.13.0.0 November 25. 2009
-------------------------------------------------------------------------------
- Support for CC430 added.
- Support for CC2530-CC2591EM added.
- CC2520-CC2591: Settings updated to support rev. 3.0
- CC1100E: Setting of VCO high/low updated for 950-960MHz (FSCAL=0x2A)
- CC111x : Settings for 2.4 kBaud data rate added.
- CC251x : RSSI offset value updated to align with data sheet.
-------------------------------------------------------------------------------
Version 6.12.0.0 August 31. 2009
-------------------------------------------------------------------------------
- Support for CC2430-CC2591 Rev. 2 added.
- CC1101, CC1100E, CC2500: Description of field in register RXBYTES updated.
- CC1101: Settings for packet TX speed implemented to improve packet TX/RX
          between CC1101EM and CC1110EM 
-------------------------------------------------------------------------------
Version 6.11.6.0 July 28. 2009
-------------------------------------------------------------------------------
- CC111x: FSCAL2 = 0x2A for all frequencies.
-------------------------------------------------------------------------------
Version 6.11.5.0 April 24. 2009
-------------------------------------------------------------------------------
- CC2530: FSCAL1 = 0x00 to reduce VCO current.
-------------------------------------------------------------------------------
Version 6.11.4.0 April 06. 2009
-------------------------------------------------------------------------------
- Support for CC1100E added.
- Support for CC2530 added.
- Support for CC Debugger added.
- CC11xx: Calculation of VCO High/Low has been updated to take into account
          the usage of channel number different from zero.
          Setting of GDO2 pin changed for asynchronous mode in simple RX.
- CC2500: DEVIATN for 250 kBaud and mod = MSK, changed from 0x01 to 0x00
-------------------------------------------------------------------------------
Version 6.10.4.0 September 30. 2008
-------------------------------------------------------------------------------
- CC2430_CC2590: Optimized output power settings for the combo board added. 
- CC2430: Radio states given in status panel(Bottom left)
- CC2420: Problem with missing dll when trying to open CC2420 window solved.
-------------------------------------------------------------------------------
Version 6.10.3.0 August 26. 2008
-------------------------------------------------------------------------------
- CC2520_CC2591: Register settings for output power for the comboboard 
                 changed (TXPOWER). 
                 AGCCTRL1 changed from 0x11 to 0x16.
- CC2430_CC2591: Improved information about the usage of High Gain Mode (HGM).
- CC1101: Poor Performance for 500 kBaud. Preferred settings for MDMCFG2 
          changed to be optimize for sensitivity. Previous settings was  
          optimized for current consumption.
- CC25xx
  CC11xx: Calculation of avarage RSSI in Packet RX mode has been coorected.          

-------------------------------------------------------------------------------
Version 6.10.2.0 July 3. 2008
-------------------------------------------------------------------------------
- CC1110: Problem with setting of TEST1 and TEST2 when changing from "Packet RX"
  to "Packet TX" or "Simple TX" solved.        
- Bug #1957 Problem with automatic update of FW if not installed on default 
            location solved.            

-------------------------------------------------------------------------------
Version 6.10.1.0 May 29. 2008  
-------------------------------------------------------------------------------

- Support for CC2520_CC2591EM added.
- Problem with Simple TX unmodulated carrier for CC2520 fixed.
  
-------------------------------------------------------------------------------
Version 6.10.0.0  May 21. 2008
-------------------------------------------------------------------------------

- Support for CC2430_CC2591EM
- Bug #2145 TX test modes for CC2520 has been changed.
- Bug #2234 Handling of "Reset and Write settings" button fixed for
            CC1100, CC1101, CC1150, CC2500 and CC2550
- Bug #2237   
  and #2235 Definition of PKTCTRL1 aligned with data sheet for CC11xx/CC25xx.         
- Bug #1700 FSCTRL1 changed for CC2500 to fix reduced sensitivity for 
            250 and 500 kBaud data rate.   
      
  